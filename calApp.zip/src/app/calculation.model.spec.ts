import { Calculation } from './calculation.model';

describe('Calculation', () => {
  it('should create an instance', () => {
    expect(new Calculation()).toBeTruthy();
  });
});
