export class User 
{
    userId: any;
    Name: string;
    username: string;
    userPassword: string;
    email: string;
    phone: string;
}
