export class Calculation 
{
    calId:any;
    calString:string;
}
